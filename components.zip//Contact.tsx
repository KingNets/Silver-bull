import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { MapPin, Phone, Mail, Clock, Building, FileText, DollarSign } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">Get In Touch</h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Ready to start trading? Contact our expert team for personalized quotes.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Request a Quote</CardTitle>
              <CardDescription className="text-gray-400">
                Fill out the form below and we'll get back to you within 24 hours.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-white">Title *</Label>
                  <Select>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Select title" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      <SelectItem value="mr">Mr.</SelectItem>
                      <SelectItem value="mrs">Mrs.</SelectItem>
                      <SelectItem value="ms">Ms.</SelectItem>
                      <SelectItem value="dr">Dr.</SelectItem>
                      <SelectItem value="prof">Prof.</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="text-white">First Name *</Label>
                  <Input
                    id="firstName"
                    placeholder="First Name"
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName" className="text-white">Last Name *</Label>
                  <Input
                    id="lastName"
                    placeholder="Last Name"
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName" className="text-white">Company Name</Label>
                  <Input
                    id="companyName"
                    placeholder="Company Name"
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="registrationNumber" className="text-white">Registration Number</Label>
                  <Input
                    id="registrationNumber"
                    placeholder="Registration Number"
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="countryOfRegistration" className="text-white">Country of Registration</Label>
                  <Input
                    id="countryOfRegistration"
                    placeholder="Country"
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Email"
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-white">Phone</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="Phone"
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-white">Interested in *</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="general-enquiry"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="general-enquiry" className="text-gray-300">General Enquiry</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="consultation"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="consultation" className="text-gray-300">Consultation</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="metal-transport"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="metal-transport" className="text-gray-300">Metal Transport</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="silver-investment"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="silver-investment" className="text-gray-300">Silver Investment</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="storage"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="storage" className="text-gray-300">Storage</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="others"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="others" className="text-gray-300">Others</Label>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-white">Approximate Investment</Label>
                <div className="grid grid-cols-1 gap-3">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="investment-100k-200k"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="investment-100k-200k" className="text-gray-300">100k-200k</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="investment-200k-300k"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="investment-200k-300k" className="text-gray-300">200k-300k</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="investment-300k-400k"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="investment-300k-400k" className="text-gray-300">300k-400k</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="investment-400k-500k"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="investment-400k-500k" className="text-gray-300">400k-500k</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="investment-500k-plus"
                      className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                    />
                    <Label htmlFor="investment-500k-plus" className="text-gray-300">500k+</Label>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="hearAbout" className="text-white">Where did you hear about us?</Label>
                <Input
                  id="hearAbout"
                  placeholder=""
                  className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-white">Your message *</Label>
                <Textarea
                  id="message"
                  placeholder="Your Message"
                  rows={6}
                  className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                />
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="newsletter"
                    className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white"
                  />
                  <Label htmlFor="newsletter" className="text-gray-300">Sign me up for newsletter</Label>
                </div>

                <div className="flex items-start space-x-2">
                  <input
                    type="checkbox"
                    id="terms"
                    className="w-4 h-4 text-white bg-gray-700 border-gray-600 rounded focus:ring-white mt-1"
                  />
                  <Label htmlFor="terms" className="text-gray-300">
                    I agree with the <a href="#" className="text-white underline">Terms Of Use</a>
                  </Label>
                </div>
              </div>

              <Button className="w-full bg-white text-black hover:bg-gray-200">
                Send Message
              </Button>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Our Location
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">
                  Tallinn, Estonia
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  Phone Numbers
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-gray-300">
                  <span className="text-white">Main:</span> +372 5049933
                </p>
                <p className="text-gray-300">
                  <span className="text-white">Business:</span> +372 53338733
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  Email Address
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-gray-300">
                  <span className="text-white">General:</span> Kaimo.rim@gmail.com
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Business Hours
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-gray-300">
                  <span className="text-white">Monday - Saturday:</span> 9:00 AM - 6:00 PM
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Building className="h-5 w-5" />
                  Company Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-gray-300">
                  <span className="text-white">Company Name:</span> Rim Invest
                </p>
                <p className="text-gray-300">
                  <span className="text-white">Registration Number:</span> 10042991
                </p>
                <p className="text-gray-300">
                  <span className="text-white">Country of Registration:</span> Estonia
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Investment Minimums
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-gray-300">
                  <span className="text-white">Starting Investment:</span> $100,000+
                </p>
                <p className="text-gray-300">
                  <span className="text-white">Note:</span> Tailored solutions for larger investments
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}